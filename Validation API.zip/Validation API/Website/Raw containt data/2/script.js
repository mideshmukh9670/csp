// Generic tab handler: any .tab-row with .tab-btn[data-rule] / [data-lang] / [data-target]
document.querySelectorAll('.tab-row').forEach(row => {
  const buttons = row.querySelectorAll('.tab-btn');
  buttons.forEach(btn => {
    btn.addEventListener('click', () => {
      const key = btn.dataset.rule || btn.dataset.lang || btn.dataset.target;
      buttons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      // panels associated with this tab row share a common ancestor section
      const scope = row.closest('section') || document;
      scope.querySelectorAll('.tab-panel, .rule-card, .code-block[data-group]').forEach(p => {
        if(p.closest('.tab-row')) return;
        p.classList.remove('active');
      });
      const target = scope.querySelector('#' + key);
      if(target) target.classList.add('active');
    });
  });
});

// FAQ accordion
document.querySelectorAll('.faq-q').forEach(q=>{
  q.addEventListener('click',()=>{
    q.parentElement.classList.toggle('open');
  });
});

// Mobile menu toggle
const menuToggle = document.querySelector('.menu-toggle');
const navList = document.querySelector('nav.main-nav ul');
if(menuToggle && navList){
  menuToggle.addEventListener('click', () => {
    const isOpen = navList.classList.toggle('open');
    if(isOpen){
      navList.style.display='flex';
      navList.style.flexDirection='column';
      navList.style.position='absolute';
      navList.style.top='72px';
      navList.style.left='0';
      navList.style.right='0';
      navList.style.background='var(--navy-2)';
      navList.style.padding='20px 24px';
      navList.style.gap='16px';
      navList.style.borderBottom='1px solid var(--line)';
    } else {
      navList.style.display='none';
    }
  });
}
