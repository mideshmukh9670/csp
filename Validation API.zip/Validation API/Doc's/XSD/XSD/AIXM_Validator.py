from lxml import etree
from pathlib import Path


def get_xml_root_info(xml_file):
    doc = etree.parse(str(xml_file))
    root = doc.getroot()

    qname = etree.QName(root)

    return {
        "root_name": qname.localname,
        "root_namespace": qname.namespace
    }


def get_xsd_target_namespace(xsd_file):
    doc = etree.parse(str(xsd_file))
    root = doc.getroot()

    return root.get("targetNamespace")


def validate_xsd(xml_file_path, xsd_file_path):
    xml_file = Path(xml_file_path)
    xsd_file = Path(xsd_file_path)

    if not xml_file.exists():
        print(f"XML file not found: {xml_file}")
        return False

    if not xsd_file.exists():
        print(f"XSD file not found: {xsd_file}")
        return False

    xml_info = get_xml_root_info(xml_file)
    xsd_namespace = get_xsd_target_namespace(xsd_file)

    print("XML root element:", xml_info["root_name"])
    print("XML root namespace:", xml_info["root_namespace"])
    print("XSD target namespace:", xsd_namespace)

    if xml_info["root_namespace"] != xsd_namespace:
        print("\nNamespace mismatch!")
        print("Your XML namespace and XSD target namespace are different.")
        print("Use matching AIXM version XSD.")
        return False

    schema_doc = etree.parse(str(xsd_file))
    schema = etree.XMLSchema(schema_doc)

    xml_doc = etree.parse(str(xml_file))

    is_valid = schema.validate(xml_doc)

    if is_valid:
        print("\nAIXM XML is valid.")
        return True

    print("\nAIXM XML is not valid.")

    for error in schema.error_log:
        print(f"Line {error.line}: {error.message}")

    return False


if __name__ == "__main__":
    xml_file = "D:/Krishna/AVDEV03/AIXM Matrix/XSD/SampleXml/Airspace.xml"

    # Use AIXM 5.1 XSD because your XML uses:
    # http://www.aixm.aero/schema/5.1/message
    xsd_file = "aixm-5-1-20100201-xsd/xsd/message/AIXM_BasicMessage.xsd"

    validate_xsd(xml_file, xsd_file)


