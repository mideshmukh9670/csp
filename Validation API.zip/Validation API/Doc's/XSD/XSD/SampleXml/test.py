import re

# Number pattern: integer or decimal, optional +/-
NUM = r"[+-]?\d+(?:\.\d+)?"

# gml:pos

POS_2D_OR_3D_PATTERN = re.compile(rf"^\s*{NUM}\s+{NUM}(?:\s+{NUM})?\s*$")

# gml:posList
POSLIST_2D_PATTERN = re.compile(rf"^\s*{NUM}\s+{NUM}(?:\s+{NUM}\s+{NUM})*\s*$")
POSLIST_3D_PATTERN = re.compile(rf"^\s*{NUM}\s+{NUM}\s+{NUM}(?:\s+{NUM}\s+{NUM}\s+{NUM})*\s*$")




def is_valid_pos_2d_or_3d(value: str) -> bool:
    return bool(POS_2D_OR_3D_PATTERN.fullmatch(value))


def is_valid_poslist_2d(value: str) -> bool:
    return bool(POSLIST_2D_PATTERN.fullmatch(value))


# def is_valid_poslist_3d(value: str) -> bool:
#     return bool(POSLIST_3D_PATTERN.fullmatch(value))



# print(is_valid_pos_2d_or_3d("19.089600 72.865600 15.255 15.444"))           # True
# print(is_valid_pos_2d_or_3d("19.089600 72.865600 120.5"))     # True

print(is_valid_poslist_2d("19.089600 72.865600 19.089600 72.865900 19.089900 72.865900 19.089900 72.865600 19.089600 "))             # True
# print(is_valid_poslist_3d("19.1 72.1 100 19.2 72.2 105"))     # True