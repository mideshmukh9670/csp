How to Run - 

uvicorn app.main:app --reload


