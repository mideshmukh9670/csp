from fastapi import FastAPI

from app.routers.validator import router


app = FastAPI(
    title="AIXM Validator API",
    version="1.0"
)


app.include_router(router)


@app.get("/")
def home():

    return {
        "message":"AIXM Validator API Running"
    }