import os

from fastapi import APIRouter
from fastapi import UploadFile
from fastapi import File
from fastapi import Depends
from fastapi import HTTPException

from app.auth import verify_api_key

router = APIRouter()


@router.post("/validate")
async def validate_xml(
    file: UploadFile = File(...),
    client=Depends(verify_api_key)
):

    if not file.filename.endswith(".xml"):
        raise HTTPException(
            status_code=400,
            detail="Only XML files are allowed."
        )

    os.makedirs("uploads", exist_ok=True)

    filepath = os.path.join("uploads", file.filename)

    with open(filepath, "wb") as buffer:
        buffer.write(await file.read())

    return {
        "status": True,
        "message": "File uploaded successfully",
        "client": client.ClientName,
        "filename": file.filename
    }