from sqlalchemy import create_engine
from urllib.parse import quote_plus
from sqlalchemy.orm import sessionmaker

from app.config import settings

connection_string = (
    f"mssql+pyodbc://{settings.DB_USERNAME}:{settings.DB_PASSWORD}"
    f"@{settings.DB_SERVER}/{settings.DB_DATABASE}"
    f"?driver={settings.DB_DRIVER.replace(' ', '+')}"
)

engine = create_engine(connection_string)


# connection_string = (
#     f"DRIVER={{{settings.DB_DRIVER}}};"
#     f"SERVER={settings.DB_SERVER};"
#     f"DATABASE={settings.DB_DATABASE};"
#     f"Trusted_Connection=yes;"
# )

# engine = create_engine(
#     f"mssql+pyodbc:///?odbc_connect={quote_plus(connection_string)}"
# )

SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine
)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()