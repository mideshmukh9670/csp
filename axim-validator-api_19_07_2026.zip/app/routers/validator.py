import os
import uuid
import time

from fastapi import (
    APIRouter,
    UploadFile,
    File,
    Depends,
    HTTPException
)

from sqlalchemy.orm import Session

from app.database import get_db
from app.auth import verify_api_key
from app.models import ValidationRequest

from app.validator_service import validate_xsd


router = APIRouter(
    prefix="/api",
    tags=["AIXM Validator"]
)


UPLOAD_PATH = "uploads"


def save_xml_file(
        file,
        environment
):

    folder = os.path.join(
        UPLOAD_PATH,
        environment
    )


    os.makedirs(
        folder,
        exist_ok=True
    )


    filename = (
        str(uuid.uuid4())
        +
        "_"
        +
        file.filename
    )


    filepath = os.path.join(
        folder,
        filename
    )


    with open(filepath, "wb") as buffer:

        buffer.write(
            file.file.read()
        )


    return filepath



async def process_validation(
        environment,
        xml_file,
        client,
        db
):

    start_time = time.time()


    xml_path = save_xml_file(
        xml_file,
        environment
    )


    result = validate_xsd(
        xml_path
    )
    print(result)


    execution_time = int(
        (time.time()-start_time)*1000
    )


    # status = result.get(
    #     "status",
    #     "FAILED"
    # )

    if isinstance(result, bool):

        status = "SUCCESS" if result else "FAILED"

    else:

        status = "SUCCESS" if result.get("status") else "FAILED"

    request = ValidationRequest(

        ClientId=client.ClientId,

        XMLFileName=xml_file.filename,

        ValidationStatus=status,

        ExecutionTimeMs=execution_time
    )


    db.add(request)

    db.commit()

    db.refresh(request)


    return {

        "requestId": request.RequestId,

        "environment": environment,

        "fileName": xml_file.filename,

        "executionTimeMs": execution_time,

        "validationResult": result

    }



@router.post("/uat/validate")
async def validate_uat(

    file: UploadFile = File(...),

    client=Depends(verify_api_key),

    db: Session = Depends(get_db)

):

    if not file.filename.endswith(".xml"):

        raise HTTPException(
            400,
            "Only XML files allowed"
        )


    return await process_validation(
        "uat",
        file,
        client,
        db
    )




@router.post("/prod/validate")
async def validate_prod(

    file: UploadFile = File(...),

    client=Depends(verify_api_key),

    db: Session = Depends(get_db)

):

    if not file.filename.endswith(".xml"):

        raise HTTPException(
            400,
            "Only XML files allowed"
        )


    return await process_validation(
        "prod",
        file,
        client,
        db
    )