from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent
ENV_FILE = BASE_DIR / ".env"

print("BASE_DIR:", BASE_DIR)
print("ENV FILE:", ENV_FILE)
print("EXISTS:", ENV_FILE.exists())


class Settings(BaseSettings):
    DB_SERVER: str
    DB_DATABASE: str
    DB_DRIVER: str
    DB_USERNAME: str | None = None
    DB_PASSWORD: str | None = None
    API_NAME: str

    model_config = SettingsConfigDict(
        env_file=str(ENV_FILE),
        extra="ignore"
    )


settings = Settings()