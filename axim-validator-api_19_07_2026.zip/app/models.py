from datetime import datetime

from sqlalchemy.orm import declarative_base
from sqlalchemy import (
    Column,
    Integer,
    BigInteger,
    String,
    Boolean,
    DateTime
)
from sqlalchemy import func


Base = declarative_base()


class ApiClient(Base):

    __tablename__ = "ApiClient"

    ClientId = Column(
        Integer,
        primary_key=True,
        autoincrement=True
    )

    ClientName = Column(
        String(100),
        nullable=False
    )

    CompanyName = Column(
        String(150)
    )

    ContactEmail = Column(
        String(150)
    )

    ApiKey = Column(
        String(255),
        nullable=False
    )

    EnvironmentId = Column(
        Integer,
        nullable=False
    )

    IsActive = Column(
        Boolean,
        nullable=False,
        default=True
    )

    CreatedOn = Column(
        DateTime,
        nullable=False,
        default=datetime.utcnow,
        server_default=func.getdate()
    )

    ExpiryDate = Column(
        DateTime
    )



class EnvironmentMaster(Base):

    __tablename__ = "EnvironmentMaster"

    EnvironmentId = Column(
        Integer,
        primary_key=True,
        autoincrement=True
    )

    EnvironmentName = Column(
        String(20),
        nullable=False
    )

    BaseUrl = Column(
        String(250)
    )

    IsActive = Column(
        Boolean,
        nullable=False,
        default=True
    )

    CreatedOn = Column(
        DateTime,
        nullable=False,
        default=datetime.utcnow,
        server_default=func.getdate()
    )



class ValidationRequest(Base):

    __tablename__ = "ValidationRequest"

    RequestId = Column(
        BigInteger,
        primary_key=True,
        autoincrement=True
    )

    ClientId = Column(
        Integer,
        nullable=False
    )

    XMLFileName = Column(
        String(250)
    )

    ValidationStatus = Column(
        String(20),
        nullable=False
    )

    ExecutionTimeMs = Column(
        Integer
    )

    RequestDate = Column(
        DateTime,
        nullable=False,
        default=datetime.utcnow,
        server_default=func.getdate()
    )



class ValidationError(Base):

    __tablename__ = "ValidationError"

    ErrorId = Column(
        BigInteger,
        primary_key=True,
        autoincrement=True
    )

    RequestId = Column(
        BigInteger,
        nullable=False
    )

    LineNumber = Column(
        Integer
    )

    ErrorMessage = Column(
        String
    )



class ApiAccessLog(Base):

    __tablename__ = "ApiAccessLog"

    LogId = Column(
        BigInteger,
        primary_key=True,
        autoincrement=True
    )

    ClientId = Column(
        Integer
    )

    Endpoint = Column(
        String(100)
    )

    HttpMethod = Column(
        String(20)
    )

    IPAddress = Column(
        String(50)
    )

    ResponseCode = Column(
        Integer
    )

    AccessTime = Column(
        DateTime,
        nullable=False,
        default=datetime.utcnow,
        server_default=func.getdate()
    )



class XSDVersion(Base):

    __tablename__ = "XSDVersion"

    XSDId = Column(
        Integer,
        primary_key=True,
        autoincrement=True
    )

    EnvironmentId = Column(
        Integer,
        nullable=False
    )

    VersionName = Column(
        String(50)
    )

    Namespace = Column(
        String(300)
    )

    XSDPath = Column(
        String(500)
    )

    IsActive = Column(
        Boolean,
        nullable=False,
        default=True
    )

    CreatedOn = Column(
        DateTime,
        nullable=False,
        default=datetime.utcnow,
        server_default=func.getdate()
    )