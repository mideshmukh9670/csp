from fastapi import Header, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import ApiClient


def verify_api_key(
        x_api_key: str = Header(...),
        db: Session = Depends(get_db)
):

    client = (
        db.query(ApiClient)
        .filter(
            ApiClient.ApiKey == x_api_key,
            ApiClient.IsActive == True
        )
        .first()
    )

    if not client:
        raise HTTPException(
            status_code=401,
            detail="Invalid API Key"
        )

    return client